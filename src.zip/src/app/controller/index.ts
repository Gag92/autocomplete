import {
  Component,
} from '@angular/core';

import { Overlay } from '@angular/cdk/overlay';


@Component({
  selector: 'app-root',
  templateUrl: '../view/index.html',
  styleUrls: ['../sass/index.scss'],
})

export class AppComponent {
  nextPosition: number = 0;
  isMenuOpen: boolean = false;
  model = '';
  options = ['1','2','31','42'];
  constructor(public overlay: Overlay) { }

  handler (e) {
    debugger
    this.options = this.options.filter(i => i.includes(this.model));
  }
}
