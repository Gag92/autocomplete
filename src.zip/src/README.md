                                Project Development specification
                      Business Management Environment(BME) WEB application.

